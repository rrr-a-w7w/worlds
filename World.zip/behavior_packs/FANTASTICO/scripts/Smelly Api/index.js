import { configuration } from "./config.js";

export const prefix = configuration.prefix;
export { chat } from "./build/interfaces/ChatBuilder.js";
export { CommandBuild } from "./build/interfaces/CommandBuilder.js";
export { EntityBuild } from "./build/EntityBuilder.js";
export { PlayerBuild } from "./build/PlayerBuilder.js";
export { numFormatter } from "./build/utils/formatter.js";

// Plugins
import "./plugins/index.js";

// Database

export * as tables from "./build/interfaces/Database/init.js";
