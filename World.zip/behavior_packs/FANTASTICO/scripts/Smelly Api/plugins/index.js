// ADD THE FOLDER TO IMPORT TO ENABLE

import "./_default/index.js";
import "./Chat Ranks/index.js";
