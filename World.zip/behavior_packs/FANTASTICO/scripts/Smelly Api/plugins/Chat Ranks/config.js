export const configuration = {
  defaultRank: "§f§lИгрок", // default rank for all members in chat
  chatCooldown: 3, // this is a cool down when players type in chat
};