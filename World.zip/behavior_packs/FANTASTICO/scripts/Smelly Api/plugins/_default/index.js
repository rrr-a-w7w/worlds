import { world } from "mojang-minecraft";
import * as SA from "../../../Smelly Api/index.js";

world.events.beforeChat.subscribe((data) => {
  try {
    if (!data.message.startsWith(SA.CommandBuild.prefix)) return;
    const args = data.message
      .slice(SA.CommandBuild.prefix.length)
      .trim()
      .split(/\s+/);
    const command = args.shift().toLowerCase();
    const getCommand = SA.CommandBuild.getAllRegistation().some(
      (element) =>
        element.name === command ||
        (element.aliases && element.aliases.includes(command))
    );
    if (!getCommand) {
      data.cancel = true;
      return SA.chat.runCommand(
        `tellraw "${data.sender.nameTag}" {"rawtext":[{"text":"§c"},{"translate":"commands.generic.unknown", "with": ["§f${command}§c"]}]}`
      );
    }
    SA.CommandBuild.getAllRegistation().forEach((element) => {
      if (
        !data.message.startsWith(SA.CommandBuild.prefix) ||
        element.name !== command
      )
        return;
      /**
       * Registration callback
       */
      if (element?.cancelMessage) data.cancel = true;
      try {
        element.callback(data, args);
      } catch (error) {
        SA.chat.runCommand(
          `tellraw "${
            data.sender.nameTag
          }" {"rawtext":[{"text":${JSON.stringify(`§c${error}`)}}]}`
        );
      }
      /**
       * Emit to 'customCommand' event listener
       */
    });
  } catch (error) {
    console.warn(`${error} : ${error.stack}`);
  }
});

const registerInformation = {
  cancelMessage: true,
  name: "test",
  description: "Sell command",
  usage: "<everything | item name>",
  example: ["sell everything", "sell diamond"],
};

SA.CommandBuild.register(registerInformation, (chatmsg, args) => {
  SA.chat.runCommand(`say boi`);
});

const pingCommandRegisterInformation = {
  cancelMessage: true,
  name: "ping",
  description: "Sell command",
  usage: "<everything | item name>",
  example: ["sell everything", "sell diamond"],
};

SA.CommandBuild.register(pingCommandRegisterInformation, (chatmsg, args) => {
  let tps = "";
  let pingTick = world.events.tick.subscribe(({ currentTick, deltaTime }) => {
    let deltaTimeArray = [];
    deltaTimeArray.unshift(deltaTime);
    if (deltaTimeArray.length > 250) {
      deltaTimeArray.pop();
    }
    tps =
      1 /
        (deltaTimeArray.reduce(
          (previousValue, currentValue) => previousValue + currentValue
        ) /
          deltaTimeArray.length) +
      "," +
      deltaTimeArray.length;
  });
  world.events.tick.unsubscribe(pingTick);
  SA.chat.runCommand(`say TPS: ${tps}`);
});
